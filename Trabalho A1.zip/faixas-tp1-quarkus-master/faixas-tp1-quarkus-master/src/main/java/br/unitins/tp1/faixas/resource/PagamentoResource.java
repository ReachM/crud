package br.unitins.tp1.faixas.resource;

import br.unitins.tp1.faixas.dto.PagamentoRequestDTO;
import br.unitins.tp1.faixas.model.Pagamento;
import br.unitins.tp1.faixas.service.PagamentoService;

import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import java.util.List;

@Path("/pagamentos")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class PagamentoResource {

    @Inject
    PagamentoService pagamentoService;

    @GET
    @Path("/{id}")
    public Pagamento findById(@PathParam("id") Long id) {
        return pagamentoService.findById(id);
    }

    @GET
    public List<Pagamento> findAll() {
        return pagamentoService.findAll();
    }

    @POST
    public Pagamento create(PagamentoRequestDTO pagamento) {
        return pagamentoService.create(pagamento);
    }

    @PUT
    @Path("/{id}")
    public void update(@PathParam("id") Long id, PagamentoRequestDTO pagamento) {
        pagamentoService.update(id, pagamento);
    }

    @DELETE
    @Path("/{id}")
    public void delete(@PathParam("id") Long id) {
        pagamentoService.delete(id);
    }
}
