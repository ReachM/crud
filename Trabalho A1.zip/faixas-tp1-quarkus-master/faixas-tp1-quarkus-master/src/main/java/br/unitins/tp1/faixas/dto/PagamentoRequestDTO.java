package br.unitins.tp1.faixas.dto;

public class PagamentoRequestDTO {
    private Long pedidoId;
    private double valor;
    private String metodo;

    
}
