package br.unitins.tp1.faixas.service;

import br.unitins.tp1.faixas.dto.PedidoRequestDTO;
import br.unitins.tp1.faixas.model.Pedido;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import java.util.List;

@ApplicationScoped
public class PedidoService {

    @PersistenceContext
    EntityManager em;

    public Pedido findById(Long id) {
        return em.find(Pedido.class, id);
    }

    public List<Pedido> findAll() {
        return em.createQuery("SELECT p FROM Pedido p", Pedido.class).getResultList();
    }

    @Transactional
    public Pedido create(PedidoRequestDTO dto) {
        Pedido pedido = new Pedido();
        pedido.setDescricao(dto.getDescricao());
        em.persist(pedido);
        return pedido;
    }

    @Transactional
    public void update(Long id, PedidoRequestDTO dto) {
        Pedido pedido = em.find(Pedido.class, id);
        pedido.setDescricao(dto.getDescricao());
    }

    @Transactional
    public void delete(Long id) {
        Pedido pedido = em.find(Pedido.class, id);
        em.remove(pedido);
    }
}
