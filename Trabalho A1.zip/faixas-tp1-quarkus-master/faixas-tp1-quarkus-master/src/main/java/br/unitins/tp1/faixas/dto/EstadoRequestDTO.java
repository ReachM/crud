package br.unitins.tp1.faixas.dto;

public record EstadoRequestDTO(String nome, String sigla) {

}
