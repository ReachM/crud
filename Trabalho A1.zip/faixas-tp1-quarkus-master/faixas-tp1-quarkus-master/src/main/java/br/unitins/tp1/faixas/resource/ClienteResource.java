package br.unitins.tp1.faixas.resource;

import br.unitins.tp1.faixas.dto.ClienteRequestDTO;
import br.unitins.tp1.faixas.model.Cliente;
import br.unitins.tp1.faixas.service.ClienteService;

import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import java.util.List;

@Path("/clientes")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ClienteResource {

    @Inject
    ClienteService clienteService;

    @GET
    @Path("/{id}")
    public Cliente findById(@PathParam("id") Long id) {
        return clienteService.findById(id);
    }

    @GET
    @Path("/search/{nome}")
    public List<Cliente> findByNome(@PathParam("nome") String nome) {
        return clienteService.findByNome(nome);
    }

    @GET
    public List<Cliente> findAll() {
        return clienteService.findAll();
    }

    @POST
    public Cliente create(ClienteRequestDTO cliente) {
        return clienteService.create(cliente);
    }

    @PUT
    @Path("/{id}")
    public void update(@PathParam("id") Long id, ClienteRequestDTO cliente) {
        clienteService.update(id, cliente);
    }

    @DELETE
    @Path("/{id}")
    public void delete(@PathParam("id") Long id) {
        clienteService.delete(id);
    }
}
