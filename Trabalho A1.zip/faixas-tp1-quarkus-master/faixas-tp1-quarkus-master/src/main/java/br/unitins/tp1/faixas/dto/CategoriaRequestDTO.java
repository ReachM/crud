package br.unitins.tp1.faixas.dto;

public class CategoriaRequestDTO {
    private String nome;

    
}
