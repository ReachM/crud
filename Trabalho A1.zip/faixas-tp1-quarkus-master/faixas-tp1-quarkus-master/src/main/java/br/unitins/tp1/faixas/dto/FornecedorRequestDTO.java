package br.unitins.tp1.faixas.dto;

public class FornecedorRequestDTO {
    private String nome;
    private String contato;

    
}
