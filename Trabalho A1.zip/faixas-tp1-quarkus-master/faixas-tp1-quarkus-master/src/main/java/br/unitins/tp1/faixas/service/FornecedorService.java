package br.unitins.tp1.faixas.service;

import br.unitins.tp1.faixas.dto.FornecedorRequestDTO;
import br.unitins.tp1.faixas.model.Fornecedor;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import java.util.List;

@ApplicationScoped
public class FornecedorService {

    @PersistenceContext
    EntityManager em;

    public Fornecedor findById(Long id) {
        return em.find(Fornecedor.class, id);
    }

    public List<Fornecedor> findAll() {
        return em.createQuery("SELECT f FROM Fornecedor f", Fornecedor.class).getResultList();
    }

    @Transactional
    public Fornecedor create(FornecedorRequestDTO dto) {
        Fornecedor fornecedor = new Fornecedor();
        fornecedor.setNome(dto.getNome());
        fornecedor.setContato(dto.getContato());
        em.persist(fornecedor);
        return fornecedor;
    }

    @Transactional
    public void update(Long id, FornecedorRequestDTO dto) {
        Fornecedor fornecedor = em.find(Fornecedor.class, id);
        fornecedor.setNome(dto.getNome());
        fornecedor.setContato(dto.getContato());
    }

    @Transactional
    public void delete(Long id) {
        Fornecedor fornecedor = em.find(Fornecedor.class, id);
        em.remove(fornecedor);
    }
}
