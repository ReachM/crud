package br.unitins.tp1.faixas.resource;

import br.unitins.tp1.faixas.dto.CategoriaRequestDTO;
import br.unitins.tp1.faixas.model.Categoria;
import br.unitins.tp1.faixas.service.CategoriaService;

import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import java.util.List;

@Path("/categorias")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CategoriaResource {

    @Inject
    CategoriaService categoriaService;

    @GET
    @Path("/{id}")
    public Categoria findById(@PathParam("id") Long id) {
        return categoriaService.findById(id);
    }

    @GET
    public List<Categoria> findAll() {
        return categoriaService.findAll();
    }

    @POST
    public Categoria create(CategoriaRequestDTO categoria) {
        return categoriaService.create(categoria);
    }

    @PUT
    @Path("/{id}")
    public void update(@PathParam("id") Long id, CategoriaRequestDTO categoria) {
        categoriaService.update(id, categoria);
    }

    @DELETE
    @Path("/{id}")
    public void delete(@PathParam("id") Long id) {
        categoriaService.delete(id);
    }
}
