package com.example.resource;

import com.example.model.Produto;
import com.example.repository.ProdutoRepository;

import javax.inject.Inject;
import javax.transaction.Transactional;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Path("/produtos")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class ProdutoResource {

    @Inject
    ProdutoRepository produtoRepository;

    @GET
    public List<Produto> listar() {
        return produtoRepository.listAll();
    }

    @GET
    @Path("/{id}")
    public Produto buscarPorId(@PathParam("id") Long id) {
        return produtoRepository.findById(id);
    }

    @POST
    @Transactional
    public Response criar(Produto produto) {
        produtoRepository.persist(produto);
        return Response.status(Response.Status.CREATED).entity(produto).build();
    }

    @PUT
    @Path("/{id}")
    @Transactional
    public Produto atualizar(@PathParam("id") Long id, Produto produto) {
        Produto entidade = produtoRepository.findById(id);
        if (entidade == null) {
            throw new WebApplicationException("Produto com ID " + id + " não existe.", Response.Status.NOT_FOUND);
        }
        entidade.setNome(produto.getNome());
        entidade.setPreco(produto.getPreco());
        return entidade;
    }

    @DELETE
    @Path("/{id}")
    @Transactional
    public Response deletar(@PathParam("id") Long id) {
        Produto produto = produtoRepository.findById(id);
        if (produto == null) {
            throw new WebApplicationException("Produto com ID " + id + " não existe.", Response.Status.NOT_FOUND);
        }
        produtoRepository.delete(produto);
        return Response.status(Response.Status.NO_CONTENT).build();
    }
}
