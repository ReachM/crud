package br.unitins.tp1.faixas.resource;

import br.unitins.tp1.faixas.dto.PedidoRequestDTO;
import br.unitins.tp1.faixas.model.Pedido;
import br.unitins.tp1.faixas.service.PedidoService;

import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import java.util.List;

@Path("/pedidos")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class PedidoResource {

    @Inject
    PedidoService pedidoService;

    @GET
    @Path("/{id}")
    public Pedido findById(@PathParam("id") Long id) {
        return pedidoService.findById(id);
    }

    @GET
    public List<Pedido> findAll() {
        return pedidoService.findAll();
    }

    @POST
    public Pedido create(PedidoRequestDTO pedido) {
        return pedidoService.create(pedido);
    }

    @PUT
    @Path("/{id}")
    public void update(@PathParam("id") Long id, PedidoRequestDTO pedido) {
        pedidoService.update(id, pedido);
    }

    @DELETE
    @Path("/{id}")
    public void delete(@PathParam("id") Long id) {
        pedidoService.delete(id);
    }
}
