package br.unitins.tp1.faixas.resource;

import br.unitins.tp1.faixas.model.Pessoa;
import br.unitins.tp1.faixas.repository.PessoaRepository;

import javax.inject.Inject;
import javax.transaction.Transactional;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

@Path("/pessoas")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public class PessoaResource {

    @Inject
    PessoaRepository pessoaRepository;

    @GET
    public List<Pessoa> getAll() {
        return pessoaRepository.listAll();
    }

    @POST
    @Transactional
    public Response create(Pessoa pessoa) {
        pessoaRepository.persist(pessoa);
        return Response.status(Response.Status.CREATED).entity(pessoa).build();
    }

    @GET
    @Path("/{id}")
    public Response getById(@PathParam("id") Long id) {
        Pessoa pessoa = pessoaRepository.findById(id);
        if (pessoa == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        return Response.ok(pessoa).build();
    }

    @PUT
    @Path("/{id}")
    @Transactional
    public Response update(@PathParam("id") Long id, Pessoa pessoa) {
        Pessoa existingPessoa = pessoaRepository.findById(id);
        if (existingPessoa == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        existingPessoa.setNome(pessoa.getNome());
        existingPessoa.setIdade(pessoa.getIdade());
        existingPessoa.setSexo(pessoa.getSexo());
        existingPessoa.setNacionalidade(pessoa.getNacionalidade());
        return Response.ok(existingPessoa).build();
    }

    @DELETE
    @Path("/{id}")
    @Transactional
    public Response delete(@PathParam("id") Long id) {
        Pessoa existingPessoa = pessoaRepository.findById(id);
        if (existingPessoa == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        pessoaRepository.delete(existingPessoa);
        return Response.noContent().build();
    }
}
