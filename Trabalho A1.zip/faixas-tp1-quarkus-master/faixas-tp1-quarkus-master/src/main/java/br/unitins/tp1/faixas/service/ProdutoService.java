package br.unitins.tp1.faixas.service;

import br.unitins.tp1.faixas.dto.ProdutoRequestDTO;
import br.unitins.tp1.faixas.model.Produto;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import java.util.List;

@ApplicationScoped
public class ProdutoService {

    @PersistenceContext
    EntityManager em;

    public Produto findById(Long id) {
        return em.find(Produto.class, id);
    }

    public List<Produto> findAll() {
        return em.createQuery("SELECT p FROM Produto p", Produto.class).getResultList();
    }

    public List<Produto> findByNome(String nome) {
        return em.createQuery("SELECT p FROM Produto p WHERE p.nome LIKE :nome", Produto.class)
                 .setParameter("nome", "%" + nome + "%")
                 .getResultList();
    }

    @Transactional
    public Produto create(ProdutoRequestDTO dto) {
        Produto produto = new Produto();
        produto.setNome(dto.getNome());
        produto.setPreco(dto.getPreco());
        em.persist(produto);
        return produto;
    }

    @Transactional
    public void update(Long id, ProdutoRequestDTO dto) {
        Produto produto = em.find(Produto.class, id);
        produto.setNome(dto.getNome());
        produto.setPreco(dto.getPreco());
    }

    @Transactional
    public void delete(Long id) {
        Produto produto = em.find(Produto.class, id);
        em.remove(produto);
    }
}
